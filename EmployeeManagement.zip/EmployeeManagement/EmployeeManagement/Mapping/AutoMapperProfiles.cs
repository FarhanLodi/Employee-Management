﻿using AutoMapper;
using EmployeeManagement.DTO.RequestDto.DepartmentRequestDto;
using EmployeeManagement.DTO.RequestDto.EmployeeRequestDto;
using EmployeeManagement.DTO.ResponseDto.DepartmentResponseDto;
using EmployeeManagement.DTO.ResponseDto.EmployeeResponseDto;
using EmployeeManagement.Models;

namespace EmployeeManagement.Mapping
{
    public class AutoMapperProfiles : Profile
    {
        public AutoMapperProfiles()
        {
            CreateMap<Department,DepartmentRequestDto>().ReverseMap();
            CreateMap<Department, DepartmentResponseDto>().ReverseMap();
            CreateMap<Department,UpdateDepartmentRequestDto>().ReverseMap();
            CreateMap<Department, UpdateDepartmentResponseDto>().ReverseMap();

            CreateMap<Employee, EmployeeRequestDto>().ReverseMap();
            CreateMap<Employee,EmployeeResponseDto>().ReverseMap();
            CreateMap<Employee, UpdateEmployeRequestDto>().ReverseMap();
            CreateMap<Employee, UpdateEmployeeResponseDto>().ReverseMap();
        }
    }
}
