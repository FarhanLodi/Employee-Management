﻿using AutoMapper;
using EmployeeManagement.DTO.RequestDto.DepartmentRequestDto;
using EmployeeManagement.DTO.ResponseDto.DepartmentResponseDto;
using EmployeeManagement.Models;
using EmployeeManagement.Repository.DepartmentRepository;
using Microsoft.AspNetCore.Mvc;

namespace EmployeeManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DepartmentController : ControllerBase
    {
        private readonly IDepartmentRepository _repository;
        private readonly IMapper _mapper;
        public DepartmentController(IDepartmentRepository repository,IMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
        }
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var existingDepartment = await _repository.GetAllAsync();
            return Ok(_mapper.Map<List<DepartmentResponseDto>>(existingDepartment));
            
        } 
        [HttpGet]
        [Route("{Id:Guid}")]
        public async Task<IActionResult> GetById([FromRoute] Guid Id)
        {
            var existingDepartment = await _repository.GetByIdAsync(Id);
            if (existingDepartment == null)
            {
                return NotFound();
            }
            return Ok(_mapper.Map<DepartmentResponseDto>(existingDepartment));
            
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] DepartmentRequestDto departmentRequestDto)
        {
            var departement =_mapper.Map<Department>(departmentRequestDto);
            var newDepartment = await _repository.CreateAsync(departement);
            if(newDepartment == null) 
            {
                return BadRequest("Department Already Exist!!");
            }
            return Ok(_mapper.Map<DepartmentResponseDto>(newDepartment));        
        }
        [HttpPut]
        [Route("{Id:Guid}")]
        public async Task<IActionResult> Update([FromRoute]Guid Id, [FromBody]UpdateDepartmentRequestDto updateDepartmentRequestDto)
        {
            var department = _mapper.Map<Department>(updateDepartmentRequestDto);
            department = await _repository.UpdateAsync(Id, department);
            if(department == null) 
            {
                return NotFound();
            }
            return Ok(_mapper.Map<UpdateDepartmentResponseDto>(department));            
        }
        [HttpDelete]
        [Route("{Id:Guid}")]
        public async Task<IActionResult> Delete([FromRoute] Guid Id)
        {
            var department = await _repository.DeleteAsync(Id);
            if (department == null)
            {
                return NotFound();
            }
            return Ok(_mapper.Map<DepartmentResponseDto>(department));
           
        }
    }
}
