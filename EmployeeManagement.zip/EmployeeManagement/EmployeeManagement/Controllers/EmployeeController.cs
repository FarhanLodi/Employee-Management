﻿using AutoMapper;
using EmployeeManagement.DTO.RequestDto.EmployeeRequestDto;
using EmployeeManagement.DTO.ResponseDto.EmployeeResponseDto;
using EmployeeManagement.Models;
using EmployeeManagement.Repository.EmployeeRepository;
using Microsoft.AspNetCore.Mvc;

namespace EmployeeManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private readonly IMapper _mapper;
        private readonly IEmployeeRepository _employee;

        public EmployeeController(IMapper mapper,IEmployeeRepository employee)
        {
            _mapper = mapper;
            _employee = employee;
        }
        [HttpPost]
        public async Task<IActionResult> Create([FromBody]EmployeeRequestDto employeeRequestDto)
        {
            var employeeDomain = _mapper.Map<Employee>(employeeRequestDto);
            employeeDomain = await _employee.CreateAsync(employeeDomain);
            if(employeeDomain == null) 
            {
                return NotFound("Invalid Department Id");
            }
            return Ok(_mapper.Map<EmployeeResponseDto>(employeeDomain));
        }
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var employee =await _employee.GetAllAsync();
            return Ok(_mapper.Map<List<EmployeeResponseDto>>(employee));
        }
        [HttpGet]
        [Route("{Id:Guid}")]
        public async Task<IActionResult> GetById([FromRoute]Guid Id)
        {
            var employee = await _employee.GetByIdAsync(Id);
            if(employee == null)
            {
                return NotFound();
            }
            return Ok(_mapper.Map<EmployeeResponseDto>(employee));
        }
        [HttpPut]
        [Route("{Id:Guid}")]
        public async Task<IActionResult> Update([FromRoute] Guid Id, [FromBody] UpdateEmployeRequestDto updateEmployeRequestDto)
        {
            var employeeDomain = _mapper.Map<Employee>(updateEmployeRequestDto);
            var employee = await _employee.UpdateAsync(Id, employeeDomain);
            if(employee == null) 
            {
                return NotFound();
            }
            return Ok(_mapper.Map<EmployeeResponseDto>(employee));   
        }
        [HttpDelete]
        [Route("{Id:Guid}")]
        public async Task<IActionResult> Delete([FromRoute]Guid Id)
        {
            var employee = await _employee.DeleteAsync(Id);
            if(employee == null)
            {
                return NotFound();
            }
            return Ok(_mapper.Map<EmployeeResponseDto>(employee));

        }
    }
}
