﻿using EmployeeManagement.Data;
using EmployeeManagement.Models;
using Microsoft.EntityFrameworkCore;

namespace EmployeeManagement.Repository.DepartmentRepository
{
    public class DepartmentRepository : IDepartmentRepository
    {
        private readonly DepartmentDbContext _context;

        public DepartmentRepository(DepartmentDbContext context)
        {
            _context = context;
        }

        public async Task<Department?> CreateAsync(Department department)
        {
            var existingDepartment = await _context.Departments.FirstOrDefaultAsync(x => x.DepartmentName == department.DepartmentName);
            if (existingDepartment != null)
            {
                return null;
            }
            await _context.Departments.AddAsync(department);
            await _context.SaveChangesAsync();
            return department;
        }

        public async Task<List<Department>> GetAllAsync()
        {
            return await _context.Departments.ToListAsync();
        }

        public async Task<Department?> GetByIdAsync(Guid Id)
        {
            return await _context.Departments.FirstOrDefaultAsync(x => x.Id == Id);
        }

        public async Task<Department?> UpdateAsync(Guid Id, Department department)
        {
            var existingDepartment = await _context.Departments.FirstOrDefaultAsync(x => x.Id == Id);
            if (existingDepartment == null)
            {
                return null;
            }
            existingDepartment.DepartmentName = department.DepartmentName;
            existingDepartment.NoOfEmployee = department.NoOfEmployee;
            await _context.SaveChangesAsync();
            return existingDepartment;
        }
        public async Task<Department?> DeleteAsync(Guid Id)
        {
            var existingDepartment = await _context.Departments.FirstOrDefaultAsync(x => x.Id == Id);
            if (existingDepartment == null)
            {
                return null;
            }
            _context.Departments.Remove(existingDepartment);
            List<Employee> employees = await _context.Employees.Where(x => x.DepartmentId == existingDepartment.Id).ToListAsync();
            foreach(var employee in employees) 
            {
                employee.DepartmentId = null;
            }
            await _context.SaveChangesAsync();
            return existingDepartment;
        }
    }
}
