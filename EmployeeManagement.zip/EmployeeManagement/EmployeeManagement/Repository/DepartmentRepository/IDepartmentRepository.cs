﻿using EmployeeManagement.Models;

namespace EmployeeManagement.Repository.DepartmentRepository
{
    public interface IDepartmentRepository
    {
        public Task<List<Department>> GetAllAsync();
        public Task<Department?> GetByIdAsync(Guid Id);
        public Task<Department?> CreateAsync(Department department);
        public Task<Department?> UpdateAsync(Guid Id, Department department);
        public Task<Department?> DeleteAsync(Guid Id);
    }
}
