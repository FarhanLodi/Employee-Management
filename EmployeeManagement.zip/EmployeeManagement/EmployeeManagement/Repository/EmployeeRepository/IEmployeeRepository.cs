﻿using EmployeeManagement.Models;

namespace EmployeeManagement.Repository.EmployeeRepository
{
    public interface IEmployeeRepository
    {
        public Task<Employee?> CreateAsync(Employee employee);
        public Task<List<Employee>> GetAllAsync();
        public Task<Employee?> GetByIdAsync(Guid Id);
        public Task<Employee?> UpdateAsync(Guid Id, Employee employee);
        public Task<Employee?> DeleteAsync(Guid Id);
    }
}
