﻿using EmployeeManagement.Data;
using EmployeeManagement.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging.Abstractions;
using System.Runtime.InteropServices;

namespace EmployeeManagement.Repository.EmployeeRepository
{
    public class EmployeeRepository : IEmployeeRepository
    {
        private readonly DepartmentDbContext _context;

        public EmployeeRepository(DepartmentDbContext context)
        {
            _context = context;
        }
        public async Task<Employee?> CreateAsync(Employee employee)
        {

            if (employee.DepartmentId != null)
            {
                var department = await _context.Departments.FirstOrDefaultAsync(x => x.Id == employee.DepartmentId);
                if (department == null)
                {
                    return null;
                }
                await _context.Employees.AddAsync(employee);
                department.NoOfEmployee = department.NoOfEmployee + 1;
            }
            else
            {
                await _context.Employees.AddAsync(employee);
            }
            await _context.SaveChangesAsync();
            return employee;
        }


        public async Task<List<Employee>> GetAllAsync()
        {
            return await _context.Employees.Include("Department").ToListAsync();
        }

        public async Task<Employee?> GetByIdAsync(Guid Id)
        {
            var existingEmployee = await _context.Employees.Include("Department").FirstOrDefaultAsync(x => x.Id == Id);
            if (existingEmployee == null)
            {
                return null;
            }
            return existingEmployee;
        }
        public async Task<Employee?> UpdateAsync(Guid Id, Employee employee)
        {
            var existingEmployee = await _context.Employees.FirstOrDefaultAsync(x => x.Id == Id);
            if (existingEmployee == null)
            {
                return null;
            }
            var departmentId = existingEmployee.DepartmentId;
            existingEmployee.Name = employee.Name;
            existingEmployee.City = employee.City;
            existingEmployee.Age = employee.Age;
            existingEmployee.State = employee.State;
            existingEmployee.DepartmentId = employee.DepartmentId;
            if (existingEmployee.DepartmentId != departmentId)
            {
                var newDepartmentId = await _context.Departments.FirstOrDefaultAsync(x => x.Id == existingEmployee.DepartmentId);
                if (newDepartmentId != null)
                {
                    newDepartmentId.NoOfEmployee = ++newDepartmentId.NoOfEmployee;
                }
                var department = await _context.Departments.FirstOrDefaultAsync(x => x.Id == departmentId);
                if (department != null && department.NoOfEmployee != 0)
                {
                    department.NoOfEmployee = --department.NoOfEmployee;
                }
            }
            await _context.SaveChangesAsync();

            return existingEmployee;
        }

        public async Task<Employee?> DeleteAsync(Guid Id)
        {
            var existingEmployee = await _context.Employees.FirstOrDefaultAsync(x => x.Id == Id);
            if (existingEmployee == null)
            {
                return null;
            }
            var department = await _context.Departments.FirstOrDefaultAsync(x => x.Id == existingEmployee.DepartmentId);
            if (department != null && department.NoOfEmployee != 0)
            {
                department.NoOfEmployee = --department.NoOfEmployee;
            }
            _context.Employees.Remove(existingEmployee);
            await _context.SaveChangesAsync();
            return existingEmployee;
        }
    }
}
