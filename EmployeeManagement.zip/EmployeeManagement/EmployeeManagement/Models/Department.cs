﻿namespace EmployeeManagement.Models
{
    public class Department
    {
        public Guid? Id { get; set; }
        public string DepartmentName { get; set; }
        public int NoOfEmployee { get; set; }
    }
}
