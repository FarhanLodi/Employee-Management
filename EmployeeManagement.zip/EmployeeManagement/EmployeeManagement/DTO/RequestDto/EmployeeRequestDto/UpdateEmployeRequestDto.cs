﻿using System.ComponentModel.DataAnnotations;

namespace EmployeeManagement.DTO.RequestDto.EmployeeRequestDto
{
    public class UpdateEmployeRequestDto
    {
        [Required]
        [MaxLength(30)]
        public string Name { get; set; }
        [Required]
        [Range(18, 99, ErrorMessage = "Please Enter age greater of equal to 18")]
        public int Age { get; set; }
        [Required]
        [MaxLength(30)]
        public string City { get; set; }
        [Required]
        [MaxLength(30)]
        public string State { get; set; }
        public Guid? DepartmentId { get; set; }
    }
}
