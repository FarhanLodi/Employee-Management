﻿using System.ComponentModel.DataAnnotations;

namespace EmployeeManagement.DTO.RequestDto.DepartmentRequestDto
{
    public class UpdateDepartmentRequestDto
    {
        [Required]
        [MaxLength(50)]
        public string DepartmentName { get; set; }
        [Required]
        [Range(0, int.MaxValue, ErrorMessage = "Please enter a value bigger or euqal to {0}")]
        public int NoOfEmployee { get; set; }
    }
}
