﻿using System.ComponentModel.DataAnnotations;

namespace EmployeeManagement.DTO.ResponseDto.DepartmentResponseDto
{
    public class UpdateDepartmentResponseDto
    {
        public Guid? Id { get; set; }
        public string DepartmentName { get; set; }
        public int NoOfEmployee { get; set; }
    }
}
