﻿using System.ComponentModel.DataAnnotations;

namespace EmployeeManagement.DTO.ResponseDto.DepartmentResponseDto
{
    public class DepartmentResponseDto
    {
        public Guid? Id { get; set; }
        public string DepartmentName { get; set; }
        public int NoOfEmployee { get; set; }
    }
}
