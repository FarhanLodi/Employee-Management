﻿namespace EmployeeManagement.DTO.ResponseDto.EmployeeResponseDto
{
    public class UpdateEmployeeResponseDto
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public Guid? DepartmentId { get; set; }
    }
}
