﻿using EmployeeManagement.Models;

namespace EmployeeManagement.DTO.ResponseDto.EmployeeResponseDto
{ 
    public class EmployeeResponseDto
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public Department Department { get; set; }
    }
}
